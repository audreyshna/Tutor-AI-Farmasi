export default function Header() {
  return (
    <header className="app-header py-4 text-center">
      <h4 className="fw-semibold mb-1">🧪 AI Tutor Farmasi</h4>
      <p className="mb-0">
        Intelligent Tutoring System — Titrasi & Analisis Kandungan Larutan
      </p>
    </header>
  );
}
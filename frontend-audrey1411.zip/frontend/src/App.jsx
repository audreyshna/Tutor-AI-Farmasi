import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import Header from "./components/Header.jsx";
import NavigationTabs from "./components/NavigationTabs.jsx";
import Footer from "./components/Footer.jsx";
import ChatbotPage from "./pages/ChatbotPage.jsx";
import UjiKandunganPage from "./pages/SampleTestPage.jsx";
import HistoryPage from "./pages/HistoryPage.jsx";
import DosenPage from "./pages/DosenPage.jsx";
import AuthPage from "./pages/AuthPage.jsx";

export default function App() {
  const [activeTab, setActiveTab] = useState("chatbot");
  const [role, setRole] = useState(null);

  // Saat app pertama kali jalan, ambil user dari localStorage
  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      setRole(userData.role || "mahasiswa");
    }
  }, []);

  const handleLoginSuccess = (selectedRole) => {
    const userData = JSON.parse(localStorage.getItem("user"));
    if (userData?.role) {
      setRole(userData.role);
    } else {
      setRole(selectedRole || "mahasiswa");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("role");
    setRole(null);
  };

  // Jika belum login, tampilkan halaman login/register
  if (!role) {
    return <AuthPage onLoginSuccess={handleLoginSuccess} />;
  }

  // Jika role = dosen atau admin, arahkan ke halaman upload materi
  if (role === "dosen" || role === "admin") {
    return (
      <div className="app-bg min-vh-100 d-flex flex-column">
        <Header />
        <main className="container pt-4 pb-2">
          <DosenPage />
        </main>
        <div className="text-center mb-3">
          <button onClick={handleLogout} className="btn btn-outline-danger btn-sm">
            Logout
          </button>
        </div>
        <Footer />
      </div>
    );
  }

  // Jika role mahasiswa, tampilkan fitur chatbot
  return (
    <div className="app-bg min-vh-100 d-flex flex-column">
      <Header />
      <NavigationTabs activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="container flex-grow-1 mb-5">
        {activeTab === "chatbot" && <ChatbotPage />}
        {activeTab === "uji" && <UjiKandunganPage />}
        {activeTab === "history" && <HistoryPage />}
      </main>
      <div className="text-center mb-3">
        <button onClick={handleLogout} className="btn btn-outline-danger btn-sm">
          Logout
        </button>
      </div>
      <Footer />
    </div>
  );
}

import { useState } from "react";

export default function RegisterPage({ onRegister, onSwitchToLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setError("");

    if (!email || !password || !confirmPassword) {
      setError("Semua field harus diisi");
      return;
    }
    if (!email.includes("@")) {
      setError("Format email tidak valid");
      return;
    }
    if (password !== confirmPassword) {
      setError("Password dan konfirmasi password tidak cocok");
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      onRegister(email, password);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Left Side */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-indigo-600 to-purple-700 p-12 flex-col justify-between relative overflow-hidden">
        <div className="absolute top-20 left-10 w-32 h-32 bg-white/20 rounded-full animate-bounce"></div>
        <div className="absolute bottom-40 right-20 w-40 h-40 bg-white/20 rounded-full animate-pulse"></div>

        <div className="relative z-10 text-white">
          <h1 className="text-2xl font-semibold mb-4">AI Tutor Farmasi</h1>
          <p className="max-w-md text-white/90">
            Intelligent Tutoring System untuk pembelajaran titrasi dan analisis kandungan larutan
          </p>

          <div className="mt-6 bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
            <h3 className="mb-3 font-semibold">Fitur Unggulan</h3>
            <ul className="space-y-2 text-sm text-white/90">
              <li>✓ Chatbot AI dengan knowledge base lengkap tentang titrasi</li>
              <li>✓ Sistem pengujian kandungan besi/tembaga dalam larutan</li>
              <li>✓ History pengujian dengan export ke Excel/CSV</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Right Side */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md space-y-8">
          <div className="lg:hidden text-center mb-8">
            <h1 className="text-indigo-900 text-xl font-semibold">AI Tutor Farmasi</h1>
          </div>

          <div className="text-center">
            <h2 className="text-gray-900 text-xl font-semibold">Daftar Akun Baru</h2>
            <p className="text-gray-600 mt-2">Buat akun untuk mulai menggunakan AI Tutor Farmasi</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && <div className="bg-red-100 text-red-700 p-2 rounded">{error}</div>}

            <div className="space-y-2">
              <label className="block mb-1 font-medium">Email</label>
              <input
                type="email"
                placeholder="nama@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                className="w-full border rounded p-3"
              />
            </div>

            <div className="space-y-2">
              <label className="block mb-1 font-medium">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Masukkan password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                  className="w-full border rounded p-3 pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                >
                  {showPassword ? "🙈" : "👁️"}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block mb-1 font-medium">Konfirmasi Password</label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Konfirmasi password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={isLoading}
                  className="w-full border rounded p-3 pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                >
                  {showConfirmPassword ? "🙈" : "👁️"}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded"
            >
              {isLoading ? "Memproses..." : "Daftar"}
            </button>

            <div className="text-center">
              <p className="text-gray-600">
                Sudah punya akun?{" "}
                <button
                  type="button"
                  onClick={onSwitchToLogin}
                  className="text-indigo-600 hover:text-indigo-700 hover:underline"
                >
                  Masuk sekarang
                </button>
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

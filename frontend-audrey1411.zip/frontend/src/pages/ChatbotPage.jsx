import React, { useState, useRef, useEffect } from "react";

export default function ChatbotPage() {
  const [messages, setMessages] = useState([
    {
      sender: "bot",
      text: "Halo 👋! Saya AI Tutor Farmasi. Silakan tanya apa saja tentang titrasi, prosedur laboratorium, atau analisis kandungan logam.",
    },
  ]); // ← penutup array & kurungnya jangan sampai kepotong

  const [input, setInput] = useState("");
  const chatEndRef = useRef(null);

  // Auto scroll ke bawah setiap kali ada pesan baru
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMsg = { sender: "user", text: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    // Simulasi respons AI
    setTimeout(() => {
      const botResponse = {
        sender: "bot",
        text: `Baik, saya catat pertanyaanmu: "${userMsg.text}". Saat ini saya hanya bisa memberi respon simulasi ya 😊`,
      };
      setMessages((prev) => [...prev, botResponse]);
    }, 700);
  };

  return (
    <div className="card glass-card mx-auto" style={{ maxWidth: "900px" }}>
      <div className="card-body">
        {/* Deskripsi di atas */}
        <div className="text-center mb-4">
          <h5 className="fw-bold text-primary mb-1">💬 AI Tutor Farmasi</h5>
          <p className="text-muted small mb-0">
            Diskusikan topik seputar titrasi, analisis logam, atau prosedur
            laboratorium. Sistem ini akan memberikan penjelasan interaktif.
          </p>
        </div>

        {/* Chat area */}
        <div className="inner-chat-card card shadow-sm mb-3 border-0">
          <div
            className="card-body chat-room"
            style={{
              height: "400px",
              overflowY: "auto",
              backgroundColor: "#f9faff",
              borderRadius: "15px",
            }}
          >
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`d-flex mb-2 ${
                  msg.sender === "bot"
                    ? "justify-content-start"
                    : "justify-content-end"
                }`}
              >
                <div
                  className={`chat-bubble p-2 px-3 ${
                    msg.sender === "bot"
                      ? "bg-white text-dark border"
                      : "bg-primary text-white"
                  }`}
                  style={{
                    borderRadius:
                      msg.sender === "bot"
                        ? "18px 18px 18px 5px"
                        : "18px 18px 5px 18px",
                    maxWidth: "75%",
                    fontSize: "15px",
                  }}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
        </div>

        {/* Input bar */}
        <div className="input-group">
          <input
            type="text"
            className="form-control rounded-start-pill"
            placeholder="Ketik pertanyaan di sini..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />
          <button
            className="btn btn-primary rounded-end-pill px-4"
            onClick={sendMessage}
          >
            ➤
          </button>
        </div>
      </div>
    </div>
  );
}

import React from "react";

export default function Footer() {
  return (
    <footer className="text-center text-muted py-3 small">
      © 2025 Tutor AI Farmasi — Titrasi & Analisis Kandungan Larutan
    </footer>
  );
}
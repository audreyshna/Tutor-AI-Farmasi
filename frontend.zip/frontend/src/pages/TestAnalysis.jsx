import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

export function TestAnalysis({ onAddResult, selectedElement }) {
  const [sampleNumber, setSampleNumber] = useState("");
  const [sampleDate, setSampleDate] = useState("");
  const [uploadedImage, setUploadedImage] = useState(null);
  const [imageName, setImageName] = useState("");
  const [result, setResult] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => setUploadedImage(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = () => {
    if (!uploadedImage || !sampleNumber || !sampleDate) return;
    setIsAnalyzing(true);

    setTimeout(() => {
      let rgb, concentration, status, element, safeLimit;
      if (selectedElement === "fe") {
        const r = Math.floor(Math.random() * 60 + 90);
        const g = Math.floor(Math.random() * 50 + 60);
        const b = Math.floor(Math.random() * 40 + 40);
        rgb = `RGB(${r}, ${g}, ${b})`;
        concentration = parseFloat((Math.random() * 0.8).toFixed(2));
        safeLimit = 0.3;
        element = "Besi (Fe)";
        status = concentration <= safeLimit ? "Aman" : "Tidak Aman";
      } else {
        const r = Math.floor(Math.random() * 60 + 60);
        const g = Math.floor(Math.random() * 70 + 100);
        const b = Math.floor(Math.random() * 80 + 140);
        rgb = `RGB(${r}, ${g}, ${b})`;
        concentration = parseFloat((Math.random() * 3).toFixed(2));
        safeLimit = 2.0;
        element = "Tembaga (Cu)";
        status = concentration <= safeLimit ? "Aman" : "Tidak Aman";
      }

      const resultData = {
        id: Date.now().toString(),
        sampleNumber,
        date: sampleDate,
        rgb,
        element,
        concentration,
        safeLimit,
        status,
        imageName,
      };

      setResult(resultData);
      onAddResult(resultData);
      setIsAnalyzing(false);
    }, 2500);
  };

  const resetForm = () => {
    setSampleNumber("");
    setSampleDate("");
    setUploadedImage(null);
    setImageName("");
    setResult(null);
  };

  const elementInfo =
    selectedElement === "fe"
      ? { name: "Besi (Fe)", color: "text-danger", bg: "bg-danger-subtle" }
      : { name: "Tembaga (Cu)", color: "text-info", bg: "bg-info-subtle" };

  return (
    <div className="container-fluid p-0">
      {/* Header */}
      <div className="mb-4">
        <h5 className={`fw-bold ${elementInfo.color}`}>
          <i className="bi bi-beaker me-2"></i> Analisis Kandungan {elementInfo.name}
        </h5>
        <p className="text-muted small">
          Upload foto sample untuk menguji kandungan {elementInfo.name.toLowerCase()}.
        </p>
      </div>

      {/* Form dan Hasil */}
      <div className="row g-4">
        {/* Form */}
        <div className="col-md-6">
          <div className="card border-0 shadow-sm">
            <div className="card-body">
              <div className="mb-3">
                <label className="form-label fw-semibold">Nomor Sample</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Contoh: S001"
                  value={sampleNumber}
                  onChange={(e) => setSampleNumber(e.target.value)}
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-semibold">Tanggal Sample</label>
                <input
                  type="date"
                  className="form-control"
                  value={sampleDate}
                  onChange={(e) => setSampleDate(e.target.value)}
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-semibold">Upload Foto Sample</label>
                <div
                  className="border border-2 border-secondary-subtle rounded text-center p-4"
                  style={{ cursor: "pointer" }}
                >
                  <input
                    type="file"
                    id="fileUpload"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="d-none"
                  />
                  <label htmlFor="fileUpload" className="text-secondary">
                    {uploadedImage ? (
                      <>
                        <i className="bi bi-image text-success fs-3"></i>
                        <p className="m-0 text-success">{imageName}</p>
                        <small className="text-muted">Klik untuk ganti foto</small>
                      </>
                    ) : (
                      <>
                        <i className="bi bi-upload fs-3"></i>
                        <p className="m-0">Klik untuk upload foto</p>
                        <small className="text-muted">Format: JPG, PNG, JPEG</small>
                      </>
                    )}
                  </label>
                </div>
              </div>

              <button
                className="btn btn-primary w-100"
                disabled={!uploadedImage || !sampleNumber || !sampleDate || isAnalyzing}
                onClick={analyzeImage}
              >
                {isAnalyzing ? (
                  <>
                    <span
                      className="spinner-border spinner-border-sm me-2"
                      role="status"
                    ></span>
                    Menganalisis...
                  </>
                ) : (
                  <>
                    <i className="bi bi-bezier2 me-2"></i>
                    Analisis Sample
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Hasil */}
        <div className="col-md-6">
          {uploadedImage && (
            <div className="card shadow-sm mb-4">
              <div className="card-header fw-bold">Preview Foto Sample</div>
              <div className="card-body">
                <img
                  src={uploadedImage}
                  alt="Preview"
                  className="img-fluid rounded"
                  style={{ height: "250px", objectFit: "cover", width: "100%" }}
                />
              </div>
            </div>
          )}

          {result && (
            <div className="card border-0 shadow-sm bg-light">
              <div className="card-header fw-bold d-flex justify-content-between align-items-center">
                Hasil Analisis
                <span
                  className={`badge rounded-pill ${
                    result.status === "Aman" ? "bg-success" : "bg-danger"
                  }`}
                >
                  {result.status}
                </span>
              </div>
              <div className="card-body">
                <p>
                  <strong>Nomor Sample:</strong> {result.sampleNumber}
                  <br />
                  <strong>Tanggal:</strong> {result.date}
                  <br />
                  <strong>RGB:</strong> {result.rgb}
                </p>
                <div
                  className="rounded mb-3"
                  style={{
                    height: "40px",
                    backgroundColor: result.rgb.replace("RGB", "rgb"),
                  }}
                ></div>

                <p>
                  <strong>Element:</strong> {result.element}
                  <br />
                  <strong>Konsentrasi:</strong> {result.concentration} mg/L
                  <br />
                  <strong>Batas Aman:</strong> {result.safeLimit} mg/L
                </p>

                <div
                  className={`alert ${
                    result.status === "Aman"
                      ? "alert-success"
                      : "alert-danger"
                  }`}
                >
                  {result.status === "Aman"
                    ? `✅ Konsentrasi ${result.element} dalam batas aman.`
                    : `⚠️ Konsentrasi ${result.element} melebihi batas aman!`}
                </div>

                <button
                  className="btn btn-outline-secondary w-100"
                  onClick={resetForm}
                >
                  Analisis Sample Baru
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {!uploadedImage && !result && (
        <div className="alert alert-info mt-4">
          Upload foto sample, isi data, lalu klik <strong>Analisis Sample</strong>.
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { ElementSelector } from "./ElementSelector.jsx";
import { TestAnalysis } from "./TestAnalysis.jsx";
import "bootstrap/dist/css/bootstrap.min.css";

export function TestSection({ onAddResult }) {
  const [selectedElement, setSelectedElement] = useState(null);

  const handleSelectElement = (element) => {
    setSelectedElement(element);
  };

  const handleBack = () => {
    setSelectedElement(null);
  };

  if (!selectedElement) {
    return <ElementSelector onSelectElement={handleSelectElement} />;
  }

  return (
    <div className="container-fluid">
      <button className="btn btn-outline-secondary mb-3" onClick={handleBack}>
        ← Kembali ke Pilihan Element
      </button>
      <TestAnalysis onAddResult={onAddResult} selectedElement={selectedElement} />
    </div>
  );
}

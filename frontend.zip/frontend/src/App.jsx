import React from "react";
import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Header from "./components/Header.jsx";
import NavigationTabs from "./components/NavigationTabs.jsx";
import Footer from "./components/Footer.jsx";
import ChatbotPage from "./pages/ChatbotPage.jsx";
import UjiKandunganPage from "./pages/SampleTestPage.jsx";
import HistoryPage from "./pages/HistoryPage.jsx";

export default function App() {
  const [activeTab, setActiveTab] = useState("chatbot");

  return (
    <div className="app-bg min-vh-100 d-flex flex-column">
      <Header />

      <NavigationTabs activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="container flex-grow-1 mb-5">
        {activeTab === "chatbot" && <ChatbotPage />}
        {activeTab === "uji" && <UjiKandunganPage />}
        {activeTab === "history" && <HistoryPage />}
      </main>

      <Footer />
    </div>
  );
}

// import { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
// import { ChatBot } from "./pages/ChatbotPage.jsx";
// import { TestSection } from "./pages/TestSection.jsx";
// import { TestHistory } from "./pages/TestHistory.jsx";

// export default function App() {
//   const [activeTab, setActiveTab] = useState("chatbot");

//   const [documents] = useState([
//     "Dasar-dasar Titrasi Asam Basa.pdf",
//     "Titrasi Kompleksometri.pdf",
//     "Titrasi Redoks dalam Farmasi.pdf",
//   ]);

//   const [testResults, setTestResults] = useState([
//     {
//       id: "1",
//       sampleNumber: "S001",
//       date: "2025-10-10",
//       rgb: "RGB(120, 85, 60)",
//       element: "Besi (Fe)",
//       concentration: 0.45,
//       status: "Aman",
//       imageName: "sample_001.jpg",
//     },
//     {
//       id: "2",
//       sampleNumber: "S002",
//       date: "2025-10-12",
//       rgb: "RGB(85, 140, 180)",
//       element: "Tembaga (Cu)",
//       concentration: 1.8,
//       status: "Tidak Aman",
//       imageName: "sample_002.jpg",
//     },
//   ]);

//   // di App.jsx, setelah const [testResults, setTestResults] = useState([...])
//   console.log("DEBUG testResults (App.jsx):", testResults);

//   const handleAddTestResult = (result) => {
//     setTestResults([...testResults, result]);
//   };

//   return (
//     <div
//       className="min-vh-100 bg-light d-flex flex-column align-items-center"
//       style={{
//         background: "linear-gradient(135deg, #eef4ff, #e0e7ff)",
//       }}
//     >
//       <div className="container py-5">
//         {/* Header */}
//         <div className="text-center mb-4">
//           <div className="d-flex justify-content-center align-items-center mb-2">
//             <i className="bi bi-beaker text-primary fs-1 me-2"></i>
//             <h1 className="text-primary fw-bold mb-0">AI Tutor Farmasi</h1>
//           </div>
//           <p className="text-secondary">
//             Intelligent Tutoring System - Titrasi & Analisis Kandungan Larutan
//           </p>
//         </div>

//         {/* Card */}
//         <div
//           className="card shadow-lg border-0 mx-auto"
//           style={{
//             background: "rgba(255, 255, 255, 0.9)",
//             backdropFilter: "blur(10px)",
//           }}
//         >
//           {/* Tabs */}
//           <ul className="nav nav-tabs justify-content-around bg-white">
//             <li className="nav-item">
//               <button
//                 className={`nav-link d-flex align-items-center gap-2 ${
//                   activeTab === "chatbot" ? "active text-primary fw-bold" : ""
//                 }`}
//                 onClick={() => setActiveTab("chatbot")}
//               >
//                 <i className="bi bi-chat-dots"></i>
//                 Chatbot
//               </button>
//             </li>
//             <li className="nav-item">
//               <button
//                 className={`nav-link d-flex align-items-center gap-2 ${
//                   activeTab === "test" ? "active text-primary fw-bold" : ""
//                 }`}
//                 onClick={() => setActiveTab("test")}
//               >
//                 <i className="bi bi-droplet-half"></i>
//                 Uji Kandungan
//               </button>
//             </li>
//             <li className="nav-item">
//               <button
//                 className={`nav-link d-flex align-items-center gap-2 ${
//                   activeTab === "history" ? "active text-primary fw-bold" : ""
//                 }`}
//                 onClick={() => setActiveTab("history")}
//               >
//                 <i className="bi bi-clock-history"></i>
//                 History
//               </button>
//             </li>
//           </ul>

//           {/* Tab Content */}
//           <div className="card-body p-4">
//             {activeTab === "chatbot" && <ChatBot documents={documents} />}
//             {activeTab === "test" && (
//               <TestSection onAddResult={handleAddTestResult} />
//             )}
//             {activeTab === "history" && <TestHistory testResults={testResults} />}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

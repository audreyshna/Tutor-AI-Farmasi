import React from "react";

import { useState } from "react";

export default function UjiKandunganPage() {
  const [selectedMetal, setSelectedMetal] = useState(null);
  const [sampleName, setSampleName] = useState("");
  const [sampleDate, setSampleDate] = useState("");
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);

  return (
    <div className="container">
      {!selectedMetal ? (
        <>
          <h5 className="text-center fw-semibold mb-2 text-primary">
            Pilih Jenis Elemen untuk Diuji
          </h5>
          <p className="text-center text-muted mb-4">
            Pilih elemen yang ingin Anda uji kandungannya dalam larutan
          </p>
          <div className="row justify-content-center g-4">
            <div className="col-md-5">
              <div
                className="card metal-card text-center p-4 shadow-sm"
                onClick={() => setSelectedMetal("Fe")}
              >
                <div className="metal-icon red-gradient">
                  <i className="bi bi-fire fs-3"></i>
                </div>
                <h5 className="fw-semibold mb-2">Besi (Fe)</h5>
                <span className="badge bg-light text-dark mb-2">
                  Batas Aman: 0.3 mg/L
                </span>
                <p className="text-muted small">
                  Analisis RGB foto sampel larutan untuk mendeteksi kandungan Fe
                </p>
              </div>
            </div>
            <div className="col-md-5">
              <div
                className="card metal-card text-center p-4 shadow-sm"
                onClick={() => setSelectedMetal("Cu")}
              >
                <div className="metal-icon blue-gradient">
                  <i className="bi bi-droplet fs-3"></i>
                </div>
                <h5 className="fw-semibold mb-2">Tembaga (Cu)</h5>
                <span className="badge bg-light text-dark mb-2">
                  Batas Aman: 2.0 mg/L
                </span>
                <p className="text-muted small">
                  Analisis RGB foto sampel larutan untuk mendeteksi kandungan Cu
                </p>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="row justify-content-center g-4 mt-3">
          <div className="col-md-6">
            <div className="card glass-card shadow-sm">
              <div className="card-body">
                <button
                  className="btn btn-outline-secondary btn-sm mb-3"
                  onClick={() => {
                    setSelectedMetal(null);
                    setResult(null);
                    setImage(null);
                  }}
                >
                  ← Kembali
                </button>
                <h5 className="fw-semibold mb-3 text-center">
                  Analisis Kandungan {selectedMetal === "Fe" ? "Besi (Fe)" : "Tembaga (Cu)"}
                </h5>

                <input
                  type="text"
                  className="form-control mb-3"
                  placeholder="Nama Sample"
                  value={sampleName}
                  onChange={(e) => setSampleName(e.target.value)}
                />
                <input
                  type="date"
                  className="form-control mb-3"
                  value={sampleDate}
                  onChange={(e) => setSampleDate(e.target.value)}
                />
                <input
                  type="file"
                  className="form-control mb-3"
                  onChange={(e) =>
                    setImage(URL.createObjectURL(e.target.files[0]))
                  }
                />

                <button
                  className="btn btn-primary w-100"
                  onClick={() =>
                    setResult({
                      rgb: "RGB(93,147,167)",
                      status: Math.random() > 0.5 ? "Aman" : "Tidak Aman",
                      kadar: (Math.random() * 2).toFixed(2),
                    })
                  }
                >
                  Analisis Sample
                </button>
              </div>
            </div>
          </div>

          {result && (
            <div className="col-md-5">
              <div className="card glass-card shadow-sm">
                <div className="card-body text-center">
                  <h6 className="fw-semibold mb-3">Hasil Analisis</h6>
                  {image && (
                    <img
                      src={image}
                      alt="Sample Preview"
                      className="img-fluid rounded mb-3 border"
                    />
                  )}
                  <p className="mb-1 small text-muted">{result.rgb}</p>
                  <h5
                    className={`fw-bold ${
                      result.status === "Aman" ? "text-success" : "text-danger"
                    }`}
                  >
                    {result.status}
                  </h5>
                  <p className="small">
                    Kandungan {selectedMetal}: {result.kadar} mg/L
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

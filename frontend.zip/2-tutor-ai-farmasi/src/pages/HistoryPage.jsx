import React from "react";

export default function HistoryPage() {
  return (
    <div className="card glass-card mx-auto" style={{ maxWidth: "800px" }}>
      <div className="card-body text-center">
        <h5 className="fw-semibold mb-3 text-primary">🕓 Riwayat Analisis</h5>
        <p className="text-muted">Belum ada riwayat analisis tersimpan.</p>
      </div>
    </div>
  );
}

# ===============================================
# 📘 convert_titrasi_to_jsonl_v2.py
# ===============================================
# Buatan untuk Siti Aisyah Nurdyanti (Ica)
# Tujuan: Mengubah PDF Modul Titrasi ke JSONL per paragraf
# Format JSONL:
# {"id": "1.1", "title": "PRINSIP TITRASI", "section": "Definisi Titrasi", "subsection": "", "subsubsection": "", "content": "..."}
# ===============================================

import fitz  # PyMuPDF
import json
import re
from pathlib import Path

# === KONFIGURASI ===
PDF_PATH = "Clean Modul Titrasi.pdf"
OUTPUT_PATH = "clean_modul_titrasi_full.jsonl"

# === 1. Pembersih teks ===
def clean_text(text: str):
    """Membersihkan teks hasil ekstraksi agar rapi."""
    text = re.sub(r'\s+', ' ', text)
    text = text.replace("‐", "-").strip()
    return text

# === 2. Deteksi struktur hierarki ===
def detect_structure(line: str):
    line = line.strip()

    # Title (semua huruf besar atau capital di awal)
    if line.isupper() and len(line.split()) <= 6:
        return "title"
    elif line.istitle() and len(line.split()) <= 6 and not re.match(r"^\d", line):
        return "section"
    elif re.match(r"^\d+\.\s", line):
        return "subsection"
    elif re.match(r"^[a-z]\.\s", line):
        return "subsubsection"
    else:
        return "content"

# === 3. Gabungkan baris terpotong ===
def merge_broken_lines(lines):
    merged = []
    buffer = ""

    for line in lines:
        # Jika baris kosong → akhiri paragraf
        if not line.strip():
            if buffer:
                merged.append(buffer.strip())
                buffer = ""
            continue

        # Jika awal paragraf baru (judul/penomoran)
        if re.match(r"^(\d+\.|[a-z]\.)\s", line) or line.isupper() or line.istitle():
            if buffer:
                merged.append(buffer.strip())
            buffer = line
        else:
            buffer += " " + line

    if buffer:
        merged.append(buffer.strip())

    return merged

# === 4. Konversi PDF ke JSONL ===
def pdf_to_jsonl(pdf_path, output_path):
    doc = fitz.open(pdf_path)
    jsonl_data = []

    current_title = ""
    current_section = ""
    current_subsection = ""
    current_subsub = ""
    section_count = 0
    content_count = 0

    for page in doc:
        text = page.get_text("text")
        raw_lines = [clean_text(l) for l in text.split("\n")]
        lines = merge_broken_lines(raw_lines)

        for line in lines:
            if not line.strip():
                continue

            level = detect_structure(line)

            if level == "title":
                current_title = line
                section_count += 1
                content_count = 0
                current_section = ""
                current_subsection = ""
                current_subsub = ""

            elif level == "section":
                current_section = line
                content_count = 0
                current_subsection = ""
                current_subsub = ""

            elif level == "subsection":
                current_subsection = re.sub(r"^\d+\.\s*", "", line)
                content_count = 0

            elif level == "subsubsection":
                current_subsub = re.sub(r"^[a-z]\.\s*", "", line)
                content_count = 0

            else:
                content_count += 1
                id_struct = f"{section_count}.{content_count}"
                jsonl_data.append({
                    "id": id_struct,
                    "title": current_title,
                    "section": current_section,
                    "subsection": current_subsection,
                    "subsubsection": current_subsub,
                    "content": line
                })

    with open(output_path, "w", encoding="utf-8") as f:
        for item in jsonl_data:
            json.dump(item, f, ensure_ascii=False)
            f.write("\n")

    print(f"✅ Berhasil! File JSONL disimpan di: {output_path}")
    print(f"Total paragraf: {len(jsonl_data)}")

# === 5. Jalankan ===
if __name__ == "__main__":
    if not Path(PDF_PATH).exists():
        print(f"❌ File '{PDF_PATH}' tidak ditemukan. Letakkan file PDF di folder yang sama dengan skrip ini.")
    else:
        pdf_to_jsonl(PDF_PATH, OUTPUT_PATH)

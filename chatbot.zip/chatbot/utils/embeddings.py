# utils/embeddings.py
from langchain_community.embeddings import SentenceTransformerEmbeddings

# gunakan model yang sama dengan build_db.py
EMBED_MODEL = "all-MiniLM-L6-v2"

# inisialisasi hanya sekali
_embedding_model = SentenceTransformerEmbeddings(model_name=EMBED_MODEL)

def embed_texts(texts):
    """
    Mengubah list teks menjadi list embedding (list of vectors)
    """
    return _embedding_model.embed_documents(texts)

def embed_text(text: str):
    """
    Mengubah satu teks jadi satu embedding vector
    """
    return _embedding_model.embed_query(text)

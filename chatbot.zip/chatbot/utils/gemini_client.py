import os
import re
import google.generativeai as genai

# === KONFIGURASI GEMINI API ===
_api_key = os.getenv("GEMINI_API_KEY")
if _api_key:
    genai.configure(api_key=_api_key)
else:
    print("⚠️ Warning: GEMINI_API_KEY tidak ditemukan di environment variables.")

# Variabel global untuk menyimpan pertanyaan terakhir (konteks percakapan)
_last_question = None


def _normalize_question(question: str) -> str:
    """
    Membersihkan pertanyaan dari kata-kata tambahan seperti 'itu apa', 'apa itu', atau 'jelaskan tentang'.
    """
    q = question.lower().strip()
    # Hilangkan frasa umum yang membuat embedding tidak akurat
    q = re.sub(r"\b(itu apa|apa itu|jelaskan tentang|apa yang dimaksud dengan)\b", "", q)
    q = q.strip(" ?")
    return q


def generate_answer_from_context(question: str, context_chunks: list, model: str = "gemini-2.0-flash") -> str:
    """
    Menghasilkan jawaban berdasarkan konteks teks menggunakan model Gemini,
    dengan dukungan normalisasi pertanyaan dan konteks percakapan.
    """
    global _last_question

    # Simpan versi asli pertanyaan
    original_question = question.strip()

    # Normalisasi pertanyaan (hilangkan "itu apa" dll)
    normalized_question = _normalize_question(original_question)

    # Jika user bertanya "itu apa" dan tidak menyebut kata baru, gunakan konteks pertanyaan sebelumnya
    if normalized_question == "" and _last_question:
        normalized_question = _last_question

    # Gabungkan semua potongan konteks
    context_text = "\n\n---\n\n".join(context_chunks)

    # Simpan pertanyaan saat ini sebagai konteks untuk pertanyaan berikutnya
    _last_question = normalized_question

    # Prompt untuk model
    prompt = f"""
Kamu adalah asisten pengajar yang cerdas. Jawab pertanyaan berdasarkan konteks di bawah ini.
Jika konteks berisi daftar, sebutkan semua poinnya. 
Jika jawaban tidak ditemukan di konteks, katakan bahwa informasinya tidak tersedia.

KONTEKS:
{context_text}

PERTANYAAN:
{normalized_question}

Jawaban singkat dan jelas:
"""

    try:
        model_instance = genai.GenerativeModel(model)

        # ✅ Gunakan region 'us-central1' agar lebih stabil
        response = model_instance.generate_content(
            prompt,
            generation_config={
                "region": "us-central1"
            }
        )

        return response.text.strip()

    except Exception as e:
        # fallback jika region tidak didukung
        try:
            response = model_instance.generate_content(prompt)
            return response.text.strip()
        except Exception as inner_e:
            return f"⚠️ Terjadi error saat generate: {inner_e}"

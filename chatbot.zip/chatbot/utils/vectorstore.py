# utils/vectorstore.py
import chromadb
from chromadb.config import Settings
import os

CHROMA_DIR = os.getenv("CHROMA_DIR", "./chroma_db")
COLLECTION_NAME = "materi"

_client = None
_collection = None

def get_client():
    global _client
    if _client is None:
        _client = chromadb.Client(Settings(persist_directory=CHROMA_DIR))
    return _client

def get_collection():
    global _collection
    if _collection is None:
        client = get_client()
        _collection = client.get_or_create_collection(COLLECTION_NAME)
    return _collection

def similarity_search_vector(query_embedding, k=4):
    collection = get_collection()
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=k
    )
    return results

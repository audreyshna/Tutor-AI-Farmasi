# ============================================
# Build Database PDF → Embedding (pakai LangChain)
# ============================================

import os
from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import Chroma

# ====== Konfigurasi ======
PDF_FOLDER = "materi"  # folder PDF
PERSIST_DIR = os.getenv("CHROMA_DIR", "./chroma_db")
EMBED_MODEL = "all-MiniLM-L6-v2"
COLLECTION_NAME = "materi"
# =========================

def main():
    # 1️⃣ Load semua PDF dari folder
    print(f"📂 Membaca semua PDF di: {PDF_FOLDER}")
    loader = PyPDFDirectoryLoader(PDF_FOLDER)
    documents = loader.load()

    # 2️⃣ Split teks jadi potongan kecil
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )
    docs = splitter.split_documents(documents)

    # 3️⃣ Buat embeddings model
    embedding = SentenceTransformerEmbeddings(model_name=EMBED_MODEL)

    # 4️⃣ Simpan ke database Chroma
    db = Chroma.from_documents(
        docs,
        embedding,
        persist_directory=PERSIST_DIR,
        collection_name=COLLECTION_NAME
    )
    db.persist()

    print(f"✅ Ingest selesai! Total chunks: {len(docs)} tersimpan di {PERSIST_DIR}")

if __name__ == "__main__":
    main()

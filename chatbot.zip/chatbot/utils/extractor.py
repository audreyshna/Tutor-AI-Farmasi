import os
from PyPDF2 import PdfReader


def extract_text_from_pdf(pdf_path: str) -> str:
    reader = PdfReader(pdf_path)
    text_parts = []
    for page in reader.pages:
        txt = page.extract_text()
        if txt:
            text_parts.append(txt)
    return "\n\n".join(text_parts)

def chunk_text(text: str, chunk_size: int = 1000, chunk_overlap: int = 200):
    """Simple char-based chunker.
    chunk_size = approx number of characters per chunk.
    Returns list of dicts: {"id":..., "text":..., "meta":{...}}
    """
    chunks = []
    start = 0
    n = len(text)
    idx = 0
    while start < n:
        end = min(start + chunk_size, n)
        chunk_text = text[start:end]
        chunks.append({
        "id": f"chunk_{idx}",
        "text": chunk_text.strip(),
        "meta": {"start": start, "end": end}
        })
        idx += 1
        start = end - chunk_overlap
        if start < 0:
            start = 0
    return chunks
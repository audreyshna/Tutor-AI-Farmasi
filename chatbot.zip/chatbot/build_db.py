# ============================================
# Build Database PDF → Embedding (pakai LangChain)
# ============================================

import os
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import Chroma

# ====== KONFIGURASI ======
MATERI_DIR = os.getenv("MATERI_DIR", "materi")  # Folder PDF
CHROMA_DIR = os.getenv("CHROMA_DIR", "./chroma_db")  # Lokasi penyimpanan DB
EMBED_MODEL = "all-MiniLM-L6-v2"  # Model embedding
COLLECTION_NAME = "materi"  # Nama koleksi Chroma
# =========================


def build_collection():
    print(f"📂 Membaca semua PDF di folder: {MATERI_DIR}")

    documents = []
    for filename in os.listdir(MATERI_DIR):
        if filename.endswith(".pdf"):
            path = os.path.join(MATERI_DIR, filename)
            print(f"➡️ Memuat file: {filename}")
            loader = PyMuPDFLoader(path)
            docs = loader.load()
            documents.extend(docs)

    if not documents:
        print("⚠ Tidak ada file PDF ditemukan di folder 'materi'")
        return

    # print(f"📚 Total halaman berhasil dimuat: {len(documents)}")
    # for i, doc in enumerate(documents[:3]):  # tampilkan 3 halaman pertama
    #     print(f"\n📝 Halaman {i+1} dari {doc.metadata.get('source', 'Unknown')}")
    #     print(doc.page_content[:500])
    
    # print(len(documents), "dokumen hasil load")
    # print([len(d.page_content) for d in documents])

    # 🔹 Split teks jadi chunk
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    )
    docs = splitter.split_documents(documents)
    print(f"📄 Total chunks: {len(docs)}")

    # 🔹 Buat embeddings
    embedding = SentenceTransformerEmbeddings(model_name=EMBED_MODEL)

    # 🔹 Buat / timpa database vektor di Chroma
    print("🧠 Membuat koleksi baru di Chroma...")
    db = Chroma.from_documents(
        docs,
        embedding,
        persist_directory=CHROMA_DIR,
        collection_name=COLLECTION_NAME
    )
    db.persist()

if __name__ == "__main__":
    build_collection()

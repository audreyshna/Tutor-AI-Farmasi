import os
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
load_dotenv()
from utils.gemini_client import generate_answer_from_context

# LangChain imports
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma

# ===== CONFIG =====
CHROMA_DIR = os.getenv("CHROMA_DIR", "./chroma_db")
EMBED_MODEL = "all-MiniLM-L6-v2"
COLLECTION_NAME = "materi"
MAX_CHARS = 8000
TOP_K = 15
# ==================

app = Flask(__name__)

# Load embedding model
embedding_model = HuggingFaceEmbeddings(model_name=EMBED_MODEL)
vectordb = Chroma(
    persist_directory=CHROMA_DIR,
    collection_name=COLLECTION_NAME,
    embedding_function=embedding_model
)

# homepage
@app.route('/')
def index():
    return render_template('index.html')

# chat UI
@app.route('/chat')
def chat_page():
    return render_template('chat.html')

# API: ask question
@app.route('/api/ask', methods=['POST'])
def api_ask():
    data = request.json
    question = data.get('question', '')
    if not question:
        return jsonify({'error': 'Pertanyaan kosong'}), 400

    # === Cari chunk paling relevan ===
    similar_docs_with_scores = vectordb.similarity_search_with_score(question, k=TOP_K * 2)
    similar_docs = [doc for doc, _ in similar_docs_with_scores]

    # === Gabungkan semua chunk relevan (bukan hanya satu halaman) ===
    context_chunks = []
    total_chars = 0
    for doc, score in similar_docs_with_scores:
        context_chunks.append(doc.page_content)
        total_chars += len(doc.page_content)
        if total_chars > MAX_CHARS:
            break

    print("\n🔍 Pertanyaan:", question)
    print(f"📄 Total dokumen relevan: {len(similar_docs)} | Total karakter konteks: {total_chars}")
    for i, d in enumerate(similar_docs[:3]):
        print(f"\nChunk {i+1} (halaman {d.metadata.get('page', '?')}):")
        print(d.page_content[:300])

    # === Generate jawaban dengan konteks yang lebih luas ===
    answer = generate_answer_from_context(question, context_chunks)
    sources = [d.metadata for d in similar_docs]

    return jsonify({
        'answer': answer,
        'sources': sources,
        'distances': None
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 5000)), debug=True)

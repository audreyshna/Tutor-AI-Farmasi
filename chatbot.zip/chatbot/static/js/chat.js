// static/js/chat.js (enhanced)
// helper append message
function appendMessage(text, who, meta = {}) {
  const box = document.getElementById('chatbox');
  const div = document.createElement('div');
  div.className = 'msg ' + (who === 'user' ? 'user' : 'bot');
  if (meta.timestamp) {
    const t = document.createElement('div');
    t.style.fontSize = '11px';
    t.style.opacity = '0.7';
    t.style.marginBottom = '6px';
    t.innerText = meta.timestamp;
    div.appendChild(t);
  }
  const p = document.createElement('div');
  p.innerText = text;
  div.appendChild(p);
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function setStatus(text) {
  document.getElementById('statusBar').innerText = text || '';
}

// send question to server
async function sendQuestion() {
  const input = document.getElementById('question');
  const q = input.value.trim();
  if (!q) return;
  appendMessage(q, 'user', { timestamp: new Date().toLocaleTimeString() });
  input.value = '';
  setStatus('Mencari jawaban...');

  // disable UI while request
  toggleUI(false);
  try {
    const resp = await fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: q })
    });
    if (!resp.ok) {
      const err = await resp.json().catch(()=>({error:resp.statusText}));
      appendMessage('Terjadi error: ' + (err.error || JSON.stringify(err)), 'bot');
      setStatus('');
      toggleUI(true);
      return;
    }
    const data = await resp.json();

    // show answer
    appendMessage(data.answer || 'Tidak ada jawaban.', 'bot', { timestamp: new Date().toLocaleTimeString() });

    // show sources (if any)
    const panel = document.getElementById('sourcePanel');
    const list = document.getElementById('sourcesList');
    list.innerHTML = '';
    if (data.sources && data.sources.length) {
      panel.style.display = 'block';
      // data.sources expected to be array of metadata objects
      data.sources.forEach((md, i) => {
        const li = document.createElement('li');
        // if metadata has source/file info, show it
        if (md && md.source) {
          li.innerText = `${i+1}. ${md.source} (chunk ${md.chunk_id || md.index || '-'})`;
        } else {
          li.innerText = `${i+1}. ${JSON.stringify(md)}`;
        }
        list.appendChild(li);
      });
    } else {
      panel.style.display = 'none';
    }

    // distances (optional) show brief note
    if (data.distances && data.distances.length) {
      const ds = data.distances.slice(0,5).map(d=>d.toFixed ? d.toFixed(3) : d).join(', ');
      setStatus('Sumber ditemukan (jarak): ' + ds);
    } else {
      setStatus('');
    }
  } catch (err) {
    console.error(err);
    appendMessage('Terjadi kesalahan jaringan atau server.', 'bot');
    setStatus('');
  } finally {
    toggleUI(true);
  }
}

function toggleUI(enabled) {
  document.getElementById('sendBtn').disabled = !enabled;
  document.getElementById('rebuildBtn').disabled = !enabled;
  document.getElementById('uploadBtn').disabled = !enabled;
  document.getElementById('question').disabled = !enabled;
  // small spinner or text
  if (!enabled) setStatus('Memproses... tunggu sebentar (bisa 10-30s tergantung ukuran DB)');
}

// upload logic
document.getElementById('uploadBtn').addEventListener('click', () => {
  document.getElementById('pdfFile').click();
});

document.getElementById('pdfFile').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  if (!f.name.toLowerCase().endsWith('.pdf')) {
    alert('Mohon pilih file PDF.');
    return;
  }
  const form = new FormData();
  form.append('file', f);
  toggleUI(false);
  setStatus('Mengunggah file PDF...');
  try {
    const res = await fetch('/upload', { method: 'POST', body: form });
    const j = await res.json();
    if (!res.ok) {
      appendMessage('Upload gagal: ' + (j.error || res.statusText), 'bot');
      setStatus('');
      toggleUI(true);
      return;
    }
    appendMessage('Upload sukses: ' + (j.filename || f.name), 'bot');
    setStatus('File diunggah. Klik Rebuild DB untuk memproses embedding.');
  } catch (err) {
    console.error(err);
    appendMessage('Upload gagal (error).', 'bot');
    setStatus('');
  } finally {
    toggleUI(true);
  }
});

// rebuild DB button
document.getElementById('rebuildBtn').addEventListener('click', async () => {
  if (!confirm('Proses rebuild akan memproses semua PDF di folder materi. Lanjutkan?')) return;
  toggleUI(false);
  setStatus('Membangun ulang DB — ini mungkin memakan waktu beberapa detik hingga menit...');
  try {
    const res = await fetch('/api/rebuild', { method: 'POST' });
    const j = await res.json();
    if (!res.ok) {
      appendMessage('Rebuild gagal: ' + (j.error || res.statusText), 'bot');
      setStatus('');
      toggleUI(true);
      return;
    }
    appendMessage('Rebuild selesai: ' + (j.status || 'OK'), 'bot');
    setStatus('Selesai membangun DB. Coba tanya sekarang.');
  } catch (err) {
    console.error(err);
    appendMessage('Rebuild gagal (error).', 'bot');
    setStatus('');
  } finally {
    toggleUI(true);
  }
});

document.getElementById('sendBtn')?.addEventListener('click', sendQuestion);
document.getElementById('question')?.addEventListener('keypress', function(e){ if (e.key === 'Enter') sendQuestion(); });
